package ph.sanpablocitygov.iSanPablo.OurGovernment

class OurGovernmentModel

{
    var ivoffice:  String = ""
    var ivdepartment:  String = ""
    var ivofficename:  String = ""



    constructor( ivoffice: String,  ivdepartment: String,  ivofficename: String )
    {
        this.ivoffice = ivoffice
        this.ivdepartment = ivdepartment
        this.ivofficename = ivofficename

    }


}