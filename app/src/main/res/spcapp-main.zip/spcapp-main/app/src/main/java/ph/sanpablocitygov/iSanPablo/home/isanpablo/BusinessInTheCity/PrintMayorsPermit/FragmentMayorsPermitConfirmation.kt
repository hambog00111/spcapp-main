package ph.sanpablocitygov.iSanPablo.home.isanpablo.BusinessInTheCity.PrintMayorsPermit

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import kotlinx.android.synthetic.main.fragment_bc_print_mayors_permit.*
import ph.sanpablocitygov.iSanPablo.R

class FragmentMayorsPermitConfirmation  :Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        val mp = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_business_mayor_permit_confirmation, null)
//
//        val mpBuilder = AlertDialog.Builder(requireContext()).setView(mp)
////        val bploDialog = mpBuilder.show()


        return view
    }
}