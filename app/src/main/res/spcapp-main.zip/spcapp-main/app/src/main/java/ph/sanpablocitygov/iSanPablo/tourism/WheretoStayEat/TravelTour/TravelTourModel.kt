package ph.sanpablocitygov.iSanPablo.tourism.WheretoStayEat.TravelTour

class TravelTourModel(var ivnamewhere : String, var ivaddwhere : String)

{

}


