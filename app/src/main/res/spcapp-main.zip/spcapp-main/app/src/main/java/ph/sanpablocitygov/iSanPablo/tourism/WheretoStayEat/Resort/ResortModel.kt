package layout.ph.sanpablocitygov.iSanPablo.cityhotlines

class ResortModel(var ivnamewhere : String, var ivaddwhere : String, var ivcontactwhere: String)

{

}


